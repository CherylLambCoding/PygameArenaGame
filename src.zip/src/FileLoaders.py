import pygame
import os


# noinspection PyArgumentList,PyArgumentList
class TileLoader:
    """
    Loads any images that have a static spriteSize
    """
    def __init__(self, width, height, subtype, filename):
        """
        :param width:
        :param height:
        :param subtype:
        :param filename:
        """
        self.sheet = pygame.image.load(os.path.join("graphics", subtype, filename)).convert()
        self.spriteSize = width, height

    def get_image(self, coords, flip_x=False, flip_y=False):
        """
        Returns a surface containing the image
        :param coords:
        :param flip_x:
        :param flip_y:
        :return:
        """
        surf = pygame.Surface(self.spriteSize).convert()
        surf.blit(self.sheet, (0, 0), (coords[0], coords[1], self.spriteSize[0], self.spriteSize[1]))
        surf.set_colorkey((0, 0, 0))
        surf = pygame.transform.flip(surf, flip_x, flip_y)
        return surf


# noinspection PyArgumentList
class SpriteSheetLoader:
    """
    Loads any images that have a varying spriteSize
    """
    def __init__(self, subtype, filename):
        self.sheet = pygame.image.load(os.path.join("graphics", subtype, filename)).convert()

    def get_image(self, size, coords, flip_x=False, flip_y=False):
        surf = pygame.Surface(size).convert()
        surf.blit(self.sheet, (0, 0), (coords[0], coords[1], size[0], size[1]))
        surf.set_colorkey((0, 0, 0))
        surf = pygame.transform.flip(surf, flip_x, flip_y)
        return surf


class SpritesManager:
    """
    Connects all the necessary features for varying spriteSize sprites to be loaded in.
    """
    def __init__(self, subtype, filename, sprite_size_dictionary, sprites_dictionary):
        """
        :param subtype:
        :param filename:
        :param sprite_size_dictionary:
        :param sprites_dictionary:
        """
        self.SpriteSheetLoader = SpriteSheetLoader(subtype, filename)
        self.SpriteSizeDictionary = sprite_size_dictionary
        self.SpritesCoordsDictionary = sprites_dictionary


class TileManager:
    """
    Manages the tiles
    """
    def __init__(self, tile_loader, cords_dictionary):
        """
        :param tile_loader:
        :param cords_dictionary:
        """
        self.TilesLoader = tile_loader
        self.CoordsDictionary = cords_dictionary
