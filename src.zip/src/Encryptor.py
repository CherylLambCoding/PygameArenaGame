# noinspection PyMethodMayBeStatic,PyStatementEffect
class ScoreReader:
    def __init__(self, filename):
        self.fileName = filename

    def get_values(self):
        with open(self.fileName, "r") as x:
            return x.read().split("/")

    def insert_new_score(self, current, new):
        scores = current
        scores.append(new)
        for i in range(len(scores)):
            if scores[i] > scores[i+1]:
                scores
