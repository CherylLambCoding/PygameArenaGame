import pygame
import os
import sys
import random
import Actors
import FileLoaders
import menus


class Game:
    def __init__(self, level, coinSpawnLocations, spawn_coords):
        self.displaySurface = pygame.display.set_mode((1600, 600))

        # the GameRunning attribute is used to control the main game loop
        self.GameRunning = True

        # These are all the fonts used during a match
        self.font = pygame.font.Font("ARCADECLASSIC.TTF", 20)
        self.fontMid = pygame.font.Font("ARCADECLASSIC.TTF", 35)
        self.fontBig = pygame.font.Font("ARCADECLASSIC.TTF", 80)


        self.score = 0
        self.scoreRender = self.fontBig.render(str(self.score), 20, (0, 0, 0))

        self.obstacles = level
        self.gravityAffected = []
        self.levelLayout = level
        self.bulletList = []
        self.enemiesList = []
        self.possibleCoinSpawnLocations = coinSpawnLocations

        # A pit is the located under the level, if an enemy comes in contact with it by falling out, it will become
        # enraged, if a player comes in contact with it, the match will end
        self.pit = Actors.Actor(0, 640, 800, 10)


        self.coinSpriteSizeDictionary = {"coin": (30, 30)}
        self.coinSpriteCoordsDictionary = {"coin": {"spinning": ((0, 0), (0, 0))}}
        self.coinImageManager = FileLoaders.SpritesManager("coin", "coin.png",
                                                           self.coinSpriteSizeDictionary,
                                                           self.coinSpriteCoordsDictionary)
        self.coinSpawner = Actors.CoinSpawner(self.coinImageManager, self.possibleCoinSpawnLocations)

        self.enemyInformation = {"normal":{"health": 100, "velocity": (5, -5), "recoilStrength": 10, "animationTick": 5, "weight": 5}}
        self.enemySpriteSizeDictionary = {"normal":(40, 52)}
        self.enemySpriteCoordsDictionary = {"normal":{"runningAnimation":((0, 0), (0, 52), (0, 104), (0, 156), (0, 208),
                                                                          (0, 260), (0, 312), (0, 364), (0, 416), (0, 468), (0, 520)),
                                                      "runningAnimationEnraged": ((40, 0), (40, 52), (40, 104), (40, 156), (40, 208),
                                                                                  (40, 260), (40, 312), (40, 364), (40, 416), (40, 468), (40, 520))}}
        self.enemyImageManager = FileLoaders.SpritesManager("enemy", "normal.png",
                                                            self.enemySpriteSizeDictionary,
                                                            self.enemySpriteCoordsDictionary)

        self.playerSpriteSizeDictionary = {}
        self.playerSpriteCoordsDictionary = {"idleAnimation": ((0, 0), (0, 56), (0, 112), (0, 168), (0, 224)), "runningAnimation": ((48, 0), (48, 56), (48, 112), (48, 168), (48, 224))}
        self.playerInformation = {"health": 100, "velocity": 10, "jumpStrength": -21, "weight": 6}
        self.playerSpritesManager = FileLoaders.SpritesManager("player", "base.png",
                                                          self.playerSpriteSizeDictionary,
                                                               self.playerSpriteCoordsDictionary)
        self.player = Actors.Player(100, 400, 48, 56, self.playerSpritesManager, self.playerInformation, self.obstacles,
                                    self.gravityAffected)




        # I tried to make it as easy as it was possible to make new weapons and enemies in the future. At the moment,
        # if you want to add a weapon you need to tell the game how big the sprite is (the names of the dictionaries
        # below should hint you towards the right one), where on the sprite sheet it is located as well as its stats
        # the type of bullet you want to use. If the bullet you want to use isn't there, it is very easy to make one,
        # just program a bullet class with the behaviour you want and then pass its reference as the value under the
        # "projectileType" key, and all should work perfectly fine. The process of adding new enemies is very similar
        # and you shouldn't have any problems doing that if you feel like it.

        self.weaponsSpritesSizeDictionary = {"pistol": {"weapon": (58, 56), "bullet": (20, 20)},
                                             "machinegun": {"weapon": (58, 56), "bullet": (20, 20)},
                                             "revolver": {"weapon": (58, 56), "bullet": (20, 20)},
                                             "sniper_rifle": {"weapon": (58, 56), "bullet": (25, 17)}}
        self.weaponsSpritesCoordsDictionary = {"pistol": {"weapon": (58, 0), "bullet": (232, 0)},
                                               "machinegun": {"weapon": (0, 0), "bullet": (232, 0)},
                                               "revolver": {"weapon": (116, 0), "bullet": (232, 0)},
                                               "sniper_rifle": {"weapon": (174, 0), "bullet": (252, 0)}}
        self.weaponsInformation = {
            "pistol": {"firerate": 25, "damage": 100, "weaponImage": 0, "bulletImage": 0, "bulletSize": (20, 20),
                       "bulletSpeed": 30, "projectileType": Actors.Bullet},
            "machinegun": {"firerate": 3, "damage": 100, "weaponImage": 0, "bulletImage": 0, "bulletSize": (20, 20),
                           "bulletSpeed": 35, "projectileType": Actors.Bullet},
            "revolver": {"firerate": 15, "damage": 200, "weaponImage": 0, "bulletImage": 0, "bulletSize": (20, 20),
                         "bulletSpeed": 40, "projectileType": Actors.Bullet},
            "sniper_rifle": {"firerate": 20, "damage": 250, "weaponImage": 0, "bulletImage": 0, "bulletSize": (20, 15),
                             "bulletSpeed": 45, "projectileType": Actors.HeavyBullet}}
        self.weaponsSpriteManager = FileLoaders.SpritesManager("weapons", "normal.png",
                                                               self.weaponsSpritesSizeDictionary,
                                                               self.weaponsSpritesCoordsDictionary)
        self.weaponManager = Actors.WeaponsManager(self.player, self.weaponsSpriteManager, self.weaponsInformation,
                                                   "machinegun", "revolver", "sniper_rifle")
        self.gun = self.weaponManager.return_weapon("pistol")


        self.spawnerImageManager = FileLoaders.TileLoader(78, 120, "other", "door.png")
        self.spawner = Actors.Spawner(spawn_coords[0], spawn_coords[1], 78, 120, 100, self.spawnerImageManager,
                                      self.enemyImageManager, self.enemyInformation)


        self.clock = pygame.time.Clock()


        self.gameoverSurface = pygame.Surface((800, 300)).convert_alpha()
        self.gameoverSurface.fill((0, 0, 0))
        self.gameoverSurface.set_alpha(128)

    # The game over screen, pretty self-explanatory, nothing too complicated, currently there is no way to start
    # another match without coming back to the main menu, because I felt like the game is better off without it, but
    # if you feel differently, you can easily change that (you just need to re-enter the game loop by changing the
    # value of the self.GameRunning attribute)
    def game_over(self):
        game_over_deciding = True
        while game_over_deciding:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    game_over_deciding = False
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_ESCAPE:
                        game_over_deciding = False
            self.displaySurface.blit(self.gameoverSurface, (0, 150))
            self.displaySurface.blit(self.fontBig.render("Game Over", 10, (255, 255, 255)), (210, 170))
            self.displaySurface.blit(self.fontMid.render("Your score was %s" % (str(self.score)), 10, (255, 255, 255)),
                                     (255, 290))
            self.displaySurface.blit(self.fontMid.render("Better Luck Next Time", 10, (255, 255, 255)), (210, 370))
            pygame.display.flip()


    # The main game loop, doing literally everything to do with gameplay
    def play(self):
        # we spawn the first coin and set self.GameRunning to True (I know we already did that, I just like to make
        # sure, a bit of a strange addiction there)
        self.coinSpawner.spawn_coin()
        self.GameRunning = True
        while self.GameRunning:
            # decrements the currentFirerate of your gun. This might sound confusing because I've done it in a bit of
            # a weird way. You can only shoot if your gun's currentFirerate attribute is lower or equal to 0, so this
            # is what this line does
            self.gun.currentFirerate -= 1

            # Fills the background with colour (no it is not laziness, I just feel like the game looks better with a
            # fill backdrop, not too distracting)
            self.displaySurface.fill((100, 100, 100))

            # The animation is set to idleAnimation so unless you do something, it is going to stay that way
            self.player.currentAnimation = self.player.idleAnimation
            # The pygame event for loop, used for the qutting the game (by quitting I mean closing down the window),
            # exiting to main menu is done by pressing escape
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Very useful variable holding onto the currently pressed keys
            keysPressed = pygame.key.get_pressed()

            # If escape is closed, it displays the game over screen and goes to the main menu
            if keysPressed[pygame.K_ESCAPE]:
                self.GameRunning = False

            # Moves to the right, sets the animation to running animation and tells the computer you are facing right
            # NOTE: The scarily sounding animation flip index is named that because animations are stored as tuples,
            # with the non-flipped version on index 0 (non-flipped = facing right) and the flipped version at index 1
            if keysPressed[pygame.K_d]:
                self.player.move(self.player.velocity, 0)
                self.player.currentAnimation = self.player.runningAnimation
                self.player.facingRight = True
                self.player.animationFlipIndex = 0

            # Moves to the right, sets the animation to running animation and tells the computer you are facing right
            # NOTE: The scarily sounding animation flip index is named that because animations are stored as tuples,
            # with the non-flipped version on index 0 (non-flipped = facing right) and the flipped version at index 1
            if keysPressed[pygame.K_a]:
                self.player.move(-self.player.velocity, 0)
                self.player.currentAnimation = self.player.runningAnimation
                self.player.facingRight = False
                self.player.animationFlipIndex = 1

            # This checks if the player is not in the air by calling the ground_check method and if he is on the ground,
            # then sets the .jumping attribute to True, causing the player to jump (the actual jump is done later in
            # this loop)
            if keysPressed[pygame.K_w] and not self.player.jumping:
                self.player.jumpDestroyed = False
                self.player.ground_check()

            # Checks if the currentFirerate is lower or equal to 0 then shoots the gun if True, does nothing if False
            if keysPressed[pygame.K_k]:
                self.gun.shoot(self.spawner.enemyList, self.bulletList)

            # If the player.jumping was set to true earlier on, this is where the player character actuall jumps
            if self.player.jumping:
                self.player.jump()

            # Draws all the ground and wall tiles
            for obstacle in self.levelLayout:
                obstacle.draw(self.displaySurface)

            # Moves the actor down based on their weight
            for actor in self.gravityAffected:
                actor.move(0, actor.weight)


            # Calls the spawn function on the spawner, which checks if the spawner is ready to spawn (there is an
            # attribute that ticks, it determines whether it is ready by checking if the attribute is equal or lower
            # then 0), if it is ready to spawn it spits out a random enemy in a random direction and then draws itself.
            self.spawner.spawn(self.obstacles)
            self.spawner.draw(self.displaySurface)


            for bullet in self.bulletList:
                # If bullet was destroyed last frame due to a collision with something, remove it from the game
                if bullet.destroyed:
                    self.bulletList.remove(bullet)

                # Otherwise move it based on it's velocity and then draw it.
                # NOTE: the code below with pygame.draw.line is for debugging only, it shows the hitbox on the bullet)
                else:
                    bullet.move(self.obstacles)
                    # pygame.draw.line(self.displaySurface, (255, 0, 0), (bullet.rect.x, bullet.rect.y),
                    #                  (bullet.rect.x + bullet.rect.width, bullet.rect.y))
                    # pygame.draw.line(self.displaySurface, (255, 0, 0), (bullet.rect.x, bullet.rect.y),
                    #                  (bullet.rect.x, bullet.rect.y + bullet.rect.height))
                    # pygame.draw.line(self.displaySurface, (255, 0, 0),
                    #                  (bullet.rect.x, bullet.rect.y + bullet.rect.height),
                    #                  (bullet.rect.x + bullet.rect.width,
                    #                   bullet.rect.y + bullet.rect.height))
                    # pygame.draw.line(self.displaySurface, (255, 0, 0),
                    #                  (bullet.rect.x + bullet.rect.width, bullet.rect.y),
                    #                  (bullet.rect.x + bullet.rect.width,
                    #                   bullet.rect.y + bullet.rect.height))
                    bullet.draw(self.displaySurface)


            for enemy in self.spawner.enemyList:
                if enemy.health <= 0:
                    self.spawner.enemyList.remove(enemy)
                elif enemy.rect.colliderect(self.pit.rect):
                    enemy.enrage()


            # Iterates over the enemies list, moves each enemy and changes their animation frame, then draws them.
            # NOTE: The pygame.draw.line code is for debugging, it shows the hitbox of the enemy
            for actor in self.spawner.enemyList:
                actor.move(actor.velocity, actor.weight)
                actor.add_animation_frame()
                # pygame.draw.line(self.displaySurface, (255, 0, 0), (actor.rect.x, actor.rect.y),
                #                  (actor.rect.x + actor.rect.width, actor.rect.y))
                # pygame.draw.line(self.displaySurface, (255, 0, 0), (actor.rect.x, actor.rect.y),
                #                  (actor.rect.x, actor.rect.y + actor.rect.height))
                # pygame.draw.line(self.displaySurface, (255, 0, 0),
                #                  (actor.rect.x, actor.rect.y + actor.rect.height),
                #                  (actor.rect.x + actor.rect.width,
                #                   actor.rect.y + actor.rect.height))
                # pygame.draw.line(self.displaySurface, (255, 0, 0),
                #                  (actor.rect.x + actor.rect.width, actor.rect.y),
                #                  (actor.rect.x + actor.rect.width,
                #                   actor.rect.y + actor.rect.height))
                actor.draw(self.displaySurface)


            #If the player collides with an enemy or the pit, enter the game over screen
            if self.player.rect.collidelist(self.spawner.enemyList) != -1 or self.player.rect.colliderect(self.pit.rect):
                self.GameRunning = False

            # If the player collides with the coin, it changes difficulty, adds to player's score and
            # gives the player a new weapon. If you want to, you can tweak the difficulty a little bit.
            if self.player.rect.colliderect(self.coinSpawner.coin.rect) or keysPressed[pygame.K_u]:
                if self.spawner.initialRate <= 75:
                    self.spawner.initialRate -= 1
                elif self.spawner.initialRate <= 50:
                    self.spawner.initialRate -= 0.5
                elif self.spawner.initialRate <= 30:
                    self.spawner.initialRate -= 0.2
                elif self.spawner.initialRate <= 0:
                    self.spawner.initialRate = 100
                else:
                    self.spawner.initialRate -= 2
                self.gun = self.weaponManager.return_random_weapon()
                self.coinSpawner.spawn_coin()
                self.score += 1
                self.scoreRender = self.fontBig.render(str(self.score), 20, (0, 0, 0))


            # NOTE: The pygame.draw.line code is for debugging, it shows the hitbox of the coin
            # pygame.draw.line(self.displaySurface, (255, 0, 0),
            #                  (self.coinSpawner.coin.rect.x, self.coinSpawner.coin.rect.y),
            #                  (self.coinSpawner.coin.rect.x + self.coinSpawner.coin.rect.width,
            #                   self.coinSpawner.coin.rect.y))
            # pygame.draw.line(self.displaySurface, (255, 0, 0),
            #                  (self.coinSpawner.coin.rect.x, self.coinSpawner.coin.rect.y),
            #                  (self.coinSpawner.coin.rect.x,
            #                   self.coinSpawner.coin.rect.y + self.coinSpawner.coin.rect.height))
            # pygame.draw.line(self.displaySurface, (255, 0, 0),
            #                  (self.coinSpawner.coin.rect.x,
            #                   self.coinSpawner.coin.rect.y + self.coinSpawner.coin.rect.height),
            #                  (
            #                      self.coinSpawner.coin.rect.x + self.coinSpawner.coin.rect.width,
            #                      self.coinSpawner.coin.rect.y + self.coinSpawner.coin.rect.height))
            # pygame.draw.line(self.displaySurface, (255, 0, 0),
            #                  (self.coinSpawner.coin.rect.x + self.coinSpawner.coin.rect.width,
            #                   self.coinSpawner.coin.rect.y),
            #                  (self.coinSpawner.coin.rect.x + self.coinSpawner.coin.rect.width,
            #                   self.coinSpawner.coin.rect.y + self.coinSpawner.coin.rect.height))
            self.coinSpawner.coin.draw(self.displaySurface)

            # NOTE: The pygame.draw.line code is for debugging, it shows the possible coin spawn locations
            # for i in self.possibleCoinSpawnLocations:
            #     pygame.draw.rect(self.displaySurface, (0, 255, 0), ((i), (3, 3)))

            # Changes the player frame (there is a ticking attribute behind this, look into Actors.py)
            self.player.add_animation_frame()
            self.player.draw(self.displaySurface)
            self.gun.draw(self.displaySurface)

            # NOTE: The pygame.draw.line code is for debugging, it shows the player hitbox
            # pygame.draw.line(self.displaySurface, (255, 0, 0), (self.player.rect.x, self.player.rect.y),
            #                  (self.player.rect.x + self.player.rect.width, self.player.rect.y))
            # pygame.draw.line(self.displaySurface, (255, 0, 0), (self.player.rect.x, self.player.rect.y),
            #                  (self.player.rect.x, self.player.rect.y + self.player.rect.height))
            # pygame.draw.line(self.displaySurface, (255, 0, 0),
            #                  (self.player.rect.x, self.player.rect.y + self.player.rect.height),
            #                  (
            #                  self.player.rect.x + self.player.rect.width, self.player.rect.y + self.player.rect.height))
            # pygame.draw.line(self.displaySurface, (255, 0, 0),
            #                  (self.player.rect.x + self.player.rect.width, self.player.rect.y),
            #                  (
            #                  self.player.rect.x + self.player.rect.width, self.player.rect.y + self.player.rect.height))


            # Blits the score to the screen
            self.displaySurface.blit(self.scoreRender, (378, 0))

            self.clock.tick(60)
            pygame.display.flip()
        self.game_over()
        return self.score




