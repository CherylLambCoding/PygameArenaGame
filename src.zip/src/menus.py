import pygame


class MainMenu:
    def __init__(self, image_manager):
        self.image_manager = image_manager
        self.mainImage = image_manager.get_image((0, 0))
        self.chosenHighlight = pygame.Surface((800, 100))
        self.chosenHighlight.fill((0, 0, 0))
        self.chosenHighlight.set_alpha(128)
        self.options = ["play", "stats", "quit"]
        self.chosenOptionIndex = 0
        self.chosenOption = self.options[self.chosenOptionIndex]
        self.chosenOptionsCoordsDict = {"play": (0, 295), "stats": (0, 395), "quit": (0, 495)}
        self.chosenOptionRect = pygame.rect.Rect(self.chosenOptionsCoordsDict[self.chosenOption], (800, 75))

    def draw(self, display):
        display.blit(self.mainImage, (0, 0))
        display.blit(self.chosenHighlight, (self.chosenOptionsCoordsDict[self.chosenOption]))

    def scroll_option(self, value):
        self.chosenOptionIndex += value
        if self.chosenOptionIndex > 2:
            self.chosenOptionIndex = 0
        if self.chosenOptionIndex < 0:
            self.chosenOptionIndex = 2
        self.chosenOption = self.options[self.chosenOptionIndex]
        self.chosenOptionRect = pygame.rect.Rect(self.chosenOptionsCoordsDict[self.chosenOption], (800, 100))


class StatsMenu:
    def __init__(self, image_manager, stats_manager):
        self.imageManager = image_manager
        self.statsManager = stats_manager
        self.mainImage = image_manager.get_image((0, 0))
        self.font = pygame.font.Font("Pixel.TTF", 72)
        self.fontMid = pygame.font.Font("ARCADECLASSIC.TTF", 72)
        # #self.font = pygame.font.SysFont('Comic Sans MS', 72)
        self.scores = ["1. x", "2. x", "3. x", "4. x", "5. x"]
        self.xOffset = 180
        self.yOffset = 100

    def draw_background(self, display):
        display.blit(self.mainImage, (0, 0))

    def draw_scores(self, display):
        y = 0
        for i in self.scores:
            display.blit(self.font.render(i, 10, (255, 255, 255)), (0 + self.xOffset, y + self.yOffset))
            y += 100
        display.blit(self.fontMid.render("Scores", 10, (255, 255, 255)), (275, 0))

    def update_stats(self):
        self.scores = self.statsManager.return_ready_score(self.statsManager.get_scores())
