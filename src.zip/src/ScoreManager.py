# noinspection PyMethodMayBeStatic
class ScoreManager:
    def __init__(self, filename):
        """
        :param filename:
        """
        self.fileName = filename

    def get_scores(self):
        """
        Returns the scores as a list of integer values
        :return:
        """
        with open(self.fileName, "r") as file:
            return [int(i) for i in (file.read().split("/"))]

    def sort_scores(self, scores):
        """
        Sorts scores descending
        :param scores:
        :return:
        """
        while True:
            swapped = False
            for i in range(len(scores) - 1):
                if scores[i] < scores[i + 1]:
                    scores[i], scores[i + 1] = scores[i + 1], scores[i]
                    print(scores)
                    swapped = True
            if not swapped:
                return scores

    def prepare_new_scores_for_writing(self, scores, new_score):
        """
        Takes in the scores, sorts them and returns them
        :param scores:
        :param new_score:
        :return:
        """
        return [i for i in self.sort_scores(scores+[new_score])][0:5]

    def overwrite_scores(self, new_scores):
        """
        Writes the given scores into files, seperated by a '/'
        :param new_scores:
        :return:
        """
        with open(self.fileName, "w") as file:
            x = "/".join([str(i) for i in new_scores])
            file.write(x)
            return True

    def return_ready_score(self, score):
        """
        Changes the score into something that can be displayed on the screen
        :param score:
        :return:
        """
        x = []
        for i in range(len(score)):
            z = str(i+1)+". " + str(score[i])
            x.append(z)
        return x
