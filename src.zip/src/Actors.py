import pygame
import random


class Actor:
    """
    Actor class is the base class for all objects that have any kind of collision detection
    :param x:
    :param y:
    :param width:
    :param height:
    """

    def __init__(self, x, y, width, height):
        self.rect = pygame.rect.Rect(x, y, width, height)


class Tile(Actor):
    """
    Tile is a block that the characters can collide with, it has an image and a rect object as its attributes
    NOTE: This class requires an image_manager object to be already instantiated when the __init__ is called.
    """

    def __init__(self, x, y, width, height, image_manager, tile, *args):
        """
        :param x:
        :param y:
        :param width:
        :param height:
        :param image_manager:
        :param tile:
        :param args:
        """
        Actor.__init__(self, x, y, width, height)
        self.kind = "tile"
        self.image = image_manager.TilesLoader.get_image(image_manager.CoordsDictionary[tile])
        for i in args:
            i.append(self)

    def draw(self, display):
        """
        Blits the tile image to the screen at the coordinates of its rect object
        :param display:
        :return:
        """
        display.blit(self.image, (self.rect.x, self.rect.y))


class Enemy(Actor):
    """
    The enemy is used for any hostile characters that the player will die once in contact with, the enemy has it's
    image, health and recoil strength which signifies how much power to apply to the recoil of their body once they are
    shot to death
    """

    def __init__(self, x, y, width, height, image_manager, enemy_information, enemy_type, obstacle_list, *args):
        """
        :param x:
        :param y:
        :param width:
        :param height:
        :param image_manager:
        :param enemy_information:
        :param enemy_type:
        :param obstacle_list:
        :param args:
        """
        Actor.__init__(self, x, y, width, height)
        self.spawn_x = x
        self.spawn_y = y
        self.enraged = False
        self.kind = "enemy"
        self.weight = enemy_information[enemy_type]["weight"]
        self.obstacle_list = obstacle_list
        self.health = enemy_information[enemy_type]["health"]
        self.velocity = enemy_information[enemy_type]["velocity"][random.randint(0, 1)]
        self.recoilStrength = enemy_information[enemy_type]["recoilStrength"]
        self.runningAnimation = []
        self.runningAnimationEnraged = []
        if self.velocity > 0:
            self.animationFlipIndex = 0
        else:
            self.animationFlipIndex = 1
        self.animationTick = enemy_information[enemy_type]["animationTick"]
        self.currentAnimationTick = self.animationTick
        self.currentAnimationFrameIndex = 0
        for keyword in image_manager.SpritesCoordsDictionary[enemy_type]:
            if keyword == "runningAnimation":
                for coords in image_manager.SpritesCoordsDictionary[enemy_type][keyword]:
                    self.runningAnimation.append((image_manager.SpriteSheetLoader.get_image
                                                  (image_manager.SpriteSizeDictionary[enemy_type], coords),
                                                  image_manager.SpriteSheetLoader.get_image
                                                  (image_manager.SpriteSizeDictionary[enemy_type], coords,
                                                   flip_x=True)))
            if keyword == "runningAnimationEnraged":
                for coords in image_manager.SpritesCoordsDictionary[enemy_type][keyword]:
                    self.runningAnimationEnraged.append((image_manager.SpriteSheetLoader.get_image
                                                         (image_manager.SpriteSizeDictionary[enemy_type], coords),
                                                         image_manager.SpriteSheetLoader.get_image
                                                         (image_manager.SpriteSizeDictionary[enemy_type], coords,
                                                          flip_x=True)))
        self.currentAnimation = self.runningAnimation
        self.currentImage = self.currentAnimation[self.currentAnimationFrameIndex]
        self.maxLength = len(self.runningAnimation) - 1
        for toAppend in args:
            toAppend.append(self)

    def draw(self, display):
        """
        Blits the current image to the screen at the coordinates of the Enemy's rect object
        :param display:
        :return:
        """
        self.currentImage = self.currentAnimation[self.currentAnimationFrameIndex][self.animationFlipIndex]
        display.blit(self.currentImage, (self.rect.x, self.rect.y))

    def move(self, x, y):
        """
        The move method doesn't do anything by itself, instead it makes a call to another method. This is done this way
        so that enemies can move in many different ways, whilst keeping the simplicity of just calling move() on each
        type
        :param x:
        :param y:
        :return:
        """
        if x != 0:
            self.move_single_axis(x, 0)
        if y != 0:
            self.move_single_axis(0, y)

    def move_single_axis(self, x, y):
        """
          allows you to change how the object moves without interfering with the move function that is actually
          called within the game loop. It also prevents an edge cutting bug. The Actor is first moved on the X axis and
          then moved on the Y axis checking for collision against the given list of collidable objects
          :param x:
          :param y:
          :return:
          """
        self.rect.x += x
        self.rect.y += y
        for obstacle in self.obstacle_list:
            if self.rect.colliderect(obstacle):
                if x > 0:
                    self.velocity *= -1
                    if self.animationFlipIndex == 1:
                        self.animationFlipIndex = 0
                    else:
                        self.animationFlipIndex = 1
                    self.rect.right = obstacle.rect.left
                if x < 0:
                    self.velocity *= -1
                    if self.animationFlipIndex == 1:
                        self.animationFlipIndex = 0
                    else:
                        self.animationFlipIndex = 1
                    self.rect.left = obstacle.rect.right
                if y > 0:
                    self.rect.bottom = obstacle.rect.top
                if y < 0:
                    self.rect.top = obstacle.rect.bottom

    def damage(self, value):
        """
        decreases the health value of the enemy, if the value is equal or lower to zero the enemy dies, and is removed
        from the game.
        :param value:
        :return:
        """
        self.health -= value

    def add_animation_frame(self):
        """
        Animates the enemy by swapping the current image to the next image in the animation sequence
        :return:
        """
        self.currentAnimationTick += 1
        if self.currentAnimationTick >= self.animationTick:
            self.currentAnimationFrameIndex += 1
            if self.currentAnimationFrameIndex > self.maxLength:
                self.currentAnimationFrameIndex = 0
            self.currentAnimationTick = 0

    def enrage(self):
        """
        Called when the enemy collides with the pit. This makes the enemy run a lot faster and changes the animation
        to enraged animation.
        :return:
        """
        self.rect.x = self.spawn_x
        self.rect.y = self.spawn_y
        if not self.enraged:
            self.currentAnimation = self.runningAnimationEnraged
            self.velocity *= 1.5
            if random.randint(0, 1) == 1:
                self.velocity *= -1
            self.enraged = True
            self.animationTick = 3
            self.weight *= 1.25


class Player(Actor):
    """
    The player class is used for any player controlled character, it has all types of animations as well as itS health,
    jumping abilities and strength. The player also controls their weapon, which is saved as an attribute that will hold
    a weapon type in order to make stuff easier to manage.
    """

    def __init__(self, x, y, width, height, image_manager, player_information, obstacle_list, *args):
        """
        :param x:
        :param y:
        :param width:
        :param height:
        :param image_manager:
        :param player_information:
        :param obstacle_list:
        :param args:
        """
        Actor.__init__(self, x, y, width, height)
        self.temporaryRect = pygame.rect.Rect(self.rect.x, self.rect.y + self.rect.height, self.rect.width, 5)
        self.facingRight = True
        self.animationFlipIndex = 0
        self.obstacle_list = obstacle_list
        self.health = player_information["health"]
        self.velocity = player_information["velocity"]
        self.jumpStrength = player_information["jumpStrength"]
        self.weight = player_information["weight"]
        self.jumpTick = 0
        self.jumping = False
        self.jumpReady = True
        self.jumpDestroyed = False
        self.runningAnimation = []
        self.idleAnimation = []
        self.animationTick = 0
        self.currentAnimationFrameIndex = 0
        self.spriteSize = width, height
        for keyword in image_manager.SpritesCoordsDictionary:
            if keyword == "idleAnimation":
                for coords in image_manager.SpritesCoordsDictionary[keyword]:
                    self.idleAnimation.append((image_manager.SpriteSheetLoader.get_image
                                               (self.spriteSize, coords), image_manager.SpriteSheetLoader.get_image
                                               (self.spriteSize, coords, flip_x=True)))
            if keyword == "runningAnimation":
                for coords in image_manager.SpritesCoordsDictionary[keyword]:
                    self.runningAnimation.append((image_manager.SpriteSheetLoader.get_image
                                                  (self.spriteSize, coords), image_manager.SpriteSheetLoader.get_image
                                                  (self.spriteSize, coords, flip_x=True)))
        self.currentAnimation = self.idleAnimation
        self.currentImage = self.currentAnimation[self.currentAnimationFrameIndex][self.animationFlipIndex]
        self.maxLength = len(self.currentAnimation) - 1
        for listForAppending in args:
            listForAppending.append(self)

    def draw(self, display):
        """
        Blits the current image to the screen at the coordinates of the rect object
        :param display:
        :return:
        """
        self.currentImage = self.currentAnimation[self.currentAnimationFrameIndex][self.animationFlipIndex]
        display.blit(self.currentImage, (self.rect.x, self.rect.y))

    def move(self, x, y):
        """
        Calls  the move_single_axis method, for more information look on the docstring of the move_single_axis()
        :param x:
        :param y:
        :return:
        """
        if x != 0:
            self.move_single_axis(x, 0)
        if y != 0:
            self.move_single_axis(0, y)

    def move_single_axis(self, x, y):
        """
        allows you to change how the object moves without interfering with the move function that is actually
        called within the game loop. It also prevents an edge cutting bug. The Actor is first moved on the X axis and
        then moved on the Y axis checking for collision against the given list of collidable objects
        :param x:
        :param y:
        :return:
        """
        self.rect.x += x
        self.rect.y += y
        for obstacle in self.obstacle_list:
            if self.rect.colliderect(obstacle):
                if x > 0:
                    self.rect.right = obstacle.rect.left
                if x < 0:
                    self.rect.left = obstacle.rect.right
                if y > 0:
                    self.rect.bottom = obstacle.rect.top
                if y < 0:
                    self.jumpDestroyed = True
                    self.rect.top = obstacle.rect.bottom

    def jump(self):
        """
        Jumps, should be called every frame the player is meant to jump. If the player contacts something with the top
        of his rect object, the jump stops (here referred to jumpDestroyed)
        :return:
        """
        if self.jumpDestroyed:
            self.jumping = False
            self.jumpTick = 0
        elif self.jumpTick <= 5:
            self.jumpTick += 1
            self.move(0, self.jumpStrength)
        elif self.jumpTick <= 10:
            self.jumpTick += 1
            self.move(0, self.jumpStrength * 0.7)
        elif self.jumpTick <= 15:
            self.jumpTick += 1
            self.move(0, self.jumpStrength * 0.45)
        elif self.jumpTick <= 20:
            self.jumpTick += 1
            self.move(0, self.jumpStrength * 0.2)
        elif self.jumpTick >= 20:
            self.jumpTick = 0
            self.jumping = False

    def ground_check(self):
        """
        Checks if the player is standing on the ground, this is used to determine whether the player should be able
        to make a jump.
        :return:
        """
        self.temporaryRect = pygame.rect.Rect(self.rect.x, self.rect.y + self.rect.height, self.rect.width, 5)
        if self.temporaryRect.collidelist(self.obstacle_list) != -1:
            self.jumping = True

    def add_animation_frame(self):
        """
        Animates by changing the current image to the next image in the animation sequence
        :return:
        """
        self.animationTick += 1
        if self.animationTick >= 10:
            self.currentAnimationFrameIndex += 1
            if self.currentAnimationFrameIndex > self.maxLength:
                self.currentAnimationFrameIndex = 0
            self.animationTick = 0


class WeaponsManager:
    """
    This class is meant to manage the weapons, it holds the information and images for each weapon and its bullets, and
    is able to return a random item of type Weapon that will be stored in a suitable attribute within an instance of a
    Player Class
    """

    def __init__(self, owner, sprite_manager, weapons_information, *args):
        """
        :param owner:
        :param sprite_manager:
        :param weapons_information:
        :param args:
        """
        self.owner = owner
        self.weaponNames = args
        self.weaponListMaxIndex = len(self.weaponNames)-1
        self.weaponsSpriteManager = sprite_manager
        self.weaponsInformation = weapons_information
        for weapon in self.weaponsInformation:
            for stat in self.weaponsInformation[weapon]:
                if stat == "weaponImage":
                    # Loading in the non flipped image into a tuple at index 0
                    self.weaponsInformation[weapon].update(
                        ({stat: (self.weaponsSpriteManager.SpriteSheetLoader.get_image(
                            self.weaponsSpriteManager.SpriteSizeDictionary[weapon]["weapon"],
                            self.weaponsSpriteManager.SpritesCoordsDictionary[weapon]["weapon"]),
                                 self.weaponsSpriteManager.SpriteSheetLoader.get_image(
                                     self.weaponsSpriteManager.SpriteSizeDictionary[weapon]["weapon"],
                                     self.weaponsSpriteManager.SpritesCoordsDictionary[weapon]["weapon"],
                                     flip_x=True))}))
                elif stat == "bulletImage":
                    self.weaponsInformation[weapon].update(
                        ({stat: (self.weaponsSpriteManager.SpriteSheetLoader.get_image(
                            self.weaponsSpriteManager.SpriteSizeDictionary[weapon]["bullet"],
                            self.weaponsSpriteManager.SpritesCoordsDictionary[weapon]["bullet"]),
                                 self.weaponsSpriteManager.SpriteSheetLoader.get_image(
                                     self.weaponsSpriteManager.SpriteSizeDictionary[weapon]["bullet"],
                                     self.weaponsSpriteManager.SpritesCoordsDictionary[weapon]["bullet"],
                                     flip_x=True))}))

    def return_weapon(self, weapon_name):
        """
        Returns a weapon, requires a weapon name
        :param weapon_name:
        :return:
        """
        return Weapon(self.weaponsInformation[weapon_name], self.owner)

    def return_random_weapon(self):
        """
        :return:
        """
        return Weapon(self.weaponsInformation[self.weaponNames[random.randint(0, self.weaponListMaxIndex)]], self.owner)


class Weapon:
    """
    This is the weapon class, it holds data about a single weapon, it should not be assigned to anything else then a
    suitable attribute within the instance of a player class
    """

    def __init__(self, weapon_info, owner):
        """
        All the weapon info is obtained from the weapon_info, which should be a dictionary.
        :param weapon_info:
        :param owner:
        """
        self.owner = owner
        self.image = weapon_info["weaponImage"][0]
        self.imageFlipped = weapon_info["weaponImage"][1]
        self.projectileType = weapon_info["projectileType"]
        self.currentImage = self.image
        self.firerate = weapon_info["firerate"]
        self.currentFirerate = self.firerate
        self.damage = weapon_info["damage"]
        self.bulletImages = weapon_info["bulletImage"]
        self.bulletImagesFlipped = weapon_info["bulletImage"][1]
        self.bulletSize = weapon_info["bulletSize"]
        self.bulletSpeed = weapon_info["bulletSpeed"]

    def shoot(self, obstacle_list, bullet_list):
        """
        Checks if the gun is able to shoot and if determined to be True (by checking its currentFirerate) it creates a
        bullet appropriate for the gun type.
        :param obstacle_list:
        :param bullet_list:
        :return:
        """
        if self.currentFirerate <= 0:
            self.projectileType(self.owner.rect.centerx, self.owner.rect.centery,
                                self.bulletSpeed, self.damage, self.bulletSize, self.bulletImages,
                                self.owner.facingRight,
                                obstacle_list, bullet_list)
            self.currentFirerate = self.firerate

    def draw(self, display):
        """
        Blits the image of the weapon onto the player
        :param display:
        :return:
        """
        if self.owner.facingRight:
            self.currentImage = self.image
            display.blit(self.currentImage, (self.owner.rect.x, self.owner.rect.y))
        else:
            self.currentImage = self.imageFlipped
            display.blit(self.currentImage, (self.owner.rect.x, self.owner.rect.y))


class Bullet(Actor):
    """
    This is the standard bullet class, it is used by many weapons, this bullet does not pass through enemies or surfaces
    it is as simple as you can imagine.
    """
    def __init__(self, x, y, bullet_speed, bullet_damage, bullet_size, bullet_image, facing_right,
                 obstacles_list, *args):
        """

        :param x:
        :param y:
        :param bullet_speed:
        :param bullet_damage:
        :param bullet_size:
        :param bullet_image:
        :param facing_right:
        :param obstacles_list:
        :param args:
        """
        Actor.__init__(self, x, y, bullet_size[0], bullet_size[1])
        self.hittable_objects = []
        self.destroyed = False
        self.obstaclesList = obstacles_list
        self.type = "Bullet"
        if facing_right:
            self.velocity = bullet_speed
            self.bulletImage = bullet_image[0]
            self.bulletDamage = bullet_damage
        else:
            self.velocity = -bullet_speed
            self.bulletImage = bullet_image[0]
            self.bulletDamage = bullet_damage
        for list_to_append in args:
            list_to_append.append(self)

    def move(self, hittable_list):
        """
        Moves the bullet whilst also checking for collision.
        :param hittable_list:
        :return:
        """
        self.hittable_objects = hittable_list
        self.rect.x += self.velocity
        for i in self.hittable_objects+self.obstaclesList:
            if self.rect.colliderect(i.rect) and i.kind == "enemy":
                self.destroyed = True
                i.damage(self.bulletDamage)
            elif self.rect.colliderect(i.rect):
                self.destroyed = True

    def draw(self, display):
        """
        Draws the bullet image onto the display, the coordinates are based on the rect object of the bullet.
        :param display:
        :return:
        """
        display.blit(self.bulletImage, (self.rect.x, self.rect.y))


class HeavyBullet(Actor):
    """
    This is a more special type of bullet, it passes through enemies, dealing damage to each one it goes through but
    gets stopped by any walls
    """
    def __init__(self, x, y, bullet_speed, bullet_damage, bullet_size, bullet_image, facing_right, obstacles_list,
                 *args):
        """
        :param x:
        :param y:
        :param bullet_speed:
        :param bullet_damage:
        :param bullet_size:
        :param bullet_image:
        :param facing_right:
        :param obstacles_list:
        :param args:
        """
        Actor.__init__(self, x, y, bullet_size[0], bullet_size[1])
        self.hittable_objects = []
        self.destroyed = False
        self.obstaclesList = obstacles_list
        if facing_right:
            self.velocity = bullet_speed
            self.bulletImage = bullet_image[0]
            self.bulletDamage = bullet_damage
        else:
            self.velocity = -bullet_speed
            self.bulletImage = bullet_image[1]
            self.bulletDamage = bullet_damage
        for list_to_append in args:
            list_to_append.append(self)
        self.type = "HeavyBullet"

    def move(self, hittable_list):
        """
        Moves the bullet, whilst checking for collisions
        :param hittable_list:
        :return:
        """
        self.hittable_objects = hittable_list
        self.rect.x += self.velocity
        for i in self.obstaclesList+self.hittable_objects:
            if self.rect.colliderect(i.rect) and i.kind == "enemy":
                i.damage(self.bulletDamage)
            elif self.rect.colliderect(i.rect):
                self.destroyed = True

    def draw(self, display):
        """
        Draws the bullet image onto the display, the coordinates are based on the rect object of the bullet.
        :param display:
        :return:
        """
        display.blit(self.bulletImage, (self.rect.x, self.rect.y))


class Spawner(Actor):
    """
    A spawner is an Actor that spawns enemies, it can pick an enemy type at random and then spawn the enemy. It holds
    the information about each possible enemy that it could spawn, and has a rate attribute which is used to set how
    often should an enemy be spawned.
    """

    def __init__(self, x, y, width, height, rate, image_manager, enemy_image_manager, enemy_information, *args):
        """
        :param x:
        :param y:
        :param width:
        :param height:
        :param rate:
        :param image_manager:
        :param enemy_image_manager:
        :param enemy_information:
        :param args:
        """
        Actor.__init__(self, x, y, width, height)
        self.initialRate = rate
        self.rate = rate
        self.enemyToRemoveList = []
        self.enemyTypes = args
        self.imageManager = image_manager
        self.image = self.imageManager.get_image((0, 0))
        self.enemyImageManager = enemy_image_manager
        self.enemyInformation = enemy_information
        self.enemyList = []

    def spawn(self, obstacles):
        """
        Checks if ready to spawn and if True, it spawns an enemy.
        :param obstacles:
        :return:
        """
        if self.rate == 0:
            Enemy(self.rect.x, self.rect.y, 40, 40, self.enemyImageManager, self.enemyInformation, "normal",
                  obstacles, self.enemyList)
            self.rate = self.initialRate
        else:
            self.rate -= 1

    def draw(self, display):
        """
        Blits its image to the screen
        :param display:
        :return:
        """
        display.blit(self.image, (self.rect.x, self.rect.y))

    def change_spawn_rate(self, value):
        """
        This method is not actually used within the game, it is for debugging purposes, it is pretty self explanatory,
        it changes the rate at which enemies spawn.
        :param value:
        :return:
        """
        self.initialRate = value


class CoinSpawner:
    """
    This class doesn't physically exist within the game, it just handles the placing of the coin.
    """
    def __init__(self, image_manager, possible_places):
        """
        :param image_manager:
        :param possible_places:
        """
        self.imageManager = image_manager
        self.coin = None
        self.images = []
        self.places_to_spawn_coins = possible_places
        self.places_length = len(self.places_to_spawn_coins) - 1
        for coords in self.imageManager.SpritesCoordsDictionary["coin"]["spinning"]:
            self.images.append(self.imageManager.SpriteSheetLoader.get_image
                               (self.imageManager.SpriteSizeDictionary["coin"], coords))

    def spawn_coin(self):
        """
        Spawns a coin at a random place
        :return:
        """
        index = random.randint(0, self.places_length)
        self.coin = Coin(self.places_to_spawn_coins[index][0],
                         self.places_to_spawn_coins[index][1],
                         self.images)


class Coin(Actor):
    def __init__(self, x, y, images):
        """
        :param x:
        :param y:
        :param images:
        """
        Actor.__init__(self, x, y, 30, 30)
        self.images = images
        self.imageIndex = 0

    def draw(self, display):
        """
        Draws its image to the screen
        :param display:
        :return:
        """
        # #pygame.draw.rect(display, (0, 0, 0), self.rect)
        display.blit(self.images[self.imageIndex], (self.rect.x, self.rect.y))

    def animate(self):
        """
        Not used so far, decided it is better for the coin to not be animated.
        :return:
        """
        self.imageIndex += 1
        if self.imageIndex >= len(self.images):
            self.imageIndex = 0
