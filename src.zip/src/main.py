import sys
import pygame
import Actors
import FileLoaders
import ScoreManager
import game
import menus

# The below initializes pygame and sets the window resolution, caption and icon.
pygame.init()
displaySurface = pygame.display.set_mode((800, 600))
iconManager = FileLoaders.TileLoader(32, 32, "other", "icon2.png")
pygame.display.set_icon(iconManager.get_image((0, 0)))
pygame.display.set_caption("Bartosz's Arcade Game")

# The below creates the main menu image manager, important thing to notice is that within this project all objects
# have their own image managers set to them. The function of an image manager is to simply distribute images.
mainMenuImageManager = FileLoaders.TileLoader(800, 600, "menu", "mainMenu.png")
mainMenu = menus.MainMenu(mainMenuImageManager)

# Creates the tile loader, preparing for loading in info about a level
tileLoader = FileLoaders.TileLoader(40, 40, "tiles", "normal.png")
tileCoordsDictionary = {"hanging": (0, 0), "wall": (40, 0)}
tileManager = FileLoaders.TileManager(tileLoader, tileCoordsDictionary)

# Creates everything needed for the stats menu
statsMenuImageManager = FileLoaders.TileLoader(800, 600, "menu", "statsMenu.png")
statsManager = ScoreManager.ScoreManager("scores.txt")
statsMenu = menus.StatsMenu(statsMenuImageManager, statsManager)


# The below is a template of a level, this allows you to customize your level any way you want.
# "w" is a wall
# "b" is a walkable surface that a coin can spawn on
# "s" is a walkable surface that a coin can't spawn on
# "e" is is a spawner, no more then 1 should be put in place at any time as the code was not written for more then one
# spawner objects. It would probably lead to the original spawner being overwritten when a new one is found, but I
# haven't actually tested it myself so it might lead to some worse issues
level = [
    "w                                  w",
    "w                                  w",
    "w                                  w",
    "w                                  w",
    "w        e                         w",
    "w     ssssssss                     w",
    "w                                  w",
    "w                bbbb   bbb      w",
    "wbbbbbbbb     bbb          bbbbbbbbw",
    "w                                  w",
    "w                                  w",
    "w            bbbbbbb               w",
    "w                                  w",
    "w                                  w",
    "wbbbbbbbbbbbbbbb   bbbbbbbbbbbbbbbbw",
]


# The below is a function that iterates over the level layout translating it into a sequence of rect objects, that are
# then put into a tuple that needs to be passed in to the play() method of the Game class.
def analyze_level(analyzed_level):
    level_obstacles = []
    coin_spawn_location = []
    spawner_coords = None
    y = 0
    for row in analyzed_level:
        x = 0
        for letter in row:
            if letter == "e":
                spawner_coords = x, y-78
            elif letter == "b":
                Actors.Tile(x, y, 40, 40, tileManager, "hanging", level_obstacles)
                coin_spawn_location.append((x, y-30))
            elif letter == "w":
                Actors.Tile(x, y, 40, 40, tileManager, "wall", level_obstacles)
            elif letter == "s":
                Actors.Tile(x, y, 40, 40, tileManager, "hanging", level_obstacles)
            x += 40
        y += 40
    return level_obstacles, coin_spawn_location, spawner_coords


clock = pygame.time.Clock()
levelsList = analyze_level(level)

# Main loop, should only be exited when closing the game
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYUP:

            if event.key == pygame.K_w:
                mainMenu.scroll_option(-1)

            if event.key == pygame.K_s:
                mainMenu.scroll_option(1)

            if event.key == pygame.K_RETURN:
                if mainMenu.chosenOption == "play":
                    # Creates an instance of a class Game and calls the .play() method, when the method finishes its
                    # activity it returns the score which is then compared to current scores and the best scores is
                    # updated, for more information look in the ScoreManager.py file.
                    match = game.Game(levelsList[0], levelsList[1], levelsList[2])
                    statsMenu.statsManager.overwrite_scores(
                        statsMenu.statsManager.prepare_new_scores_for_writing(statsMenu.statsManager.get_scores(),
                                                                              match.play()))

                elif mainMenu.chosenOption == "stats":
                    browsingStats = True
                    # .update_stats() synchronizes the game data with the data written into scores file
                    statsMenu.update_stats()
                    while browsingStats:
                        statsMenu.draw_background(displaySurface)
                        statsMenu.draw_scores(displaySurface)
                        # noinspection PyAssignmentToLoopOrWithParameter
                        for event in pygame.event.get():
                            if event.type == pygame.QUIT:
                                pygame.quit()
                                sys.exit()
                            if event.type == pygame.KEYUP:
                                if event.key == pygame.K_ESCAPE:
                                    browsingStats = False
                        pygame.display.flip()

                elif mainMenu.chosenOption == "quit":
                    pygame.quit()
                    sys.exit()

    mainMenu.draw(displaySurface)
    clock.tick(60)
    pygame.display.flip()
